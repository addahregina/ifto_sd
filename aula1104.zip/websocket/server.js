const express = require("express");
const { Socket } = require("socket.io");
const app = express();
//torna publico os arquivos estáticos da pasta public
app.use(express.static("public"));


const http = require("http").createServer(app);

//const newServer =require("socket.io")
//const serverSocket = newServer();
const serverSocket = require("socket.io")(http)

const PORT = 8000;
//a aplicação pode ser iniciada com express(app) ou http(http), porém com http websoket deve utilizar http
//app.listen(PORT, ()=> console.log(`Servidor iniciado na porta ${PORT}`));
//socket no frontend é padrão dos navegadores, 
//http (listener). app (callback), handler(manipulador)
http.listen(PORT, ()=> console.log(`Servidor iniciado na porta ${PORT}`));

//req(request), res(ponse)
app.get("/",(req, res)=> res.sendFile(__dirname + "/index.html"));

//connection é um evento
serverSocket.on("connection", (socket) => {
  console.log(`Client ${socket.id} conectou`)
  socket.on("message", (texto) => {
    console.log(`Msg recebida de ${socket.id}: ${texto}`)
    serverSocket.emit("message", texto)
  })
})
/*
node: npm --watch nomedoarquivo.js   atualiza automaticamente 
 no node pode criar entradas personalizadas, npm run "entrada". ex: "dev": "node --watch server.js
 node -d nodemon
 npm i atualiza
 npm i -D nodemon
     //"dev": "node --watch server.js"   //em versões anteriores, usar o nodemon, "dev": "nodemon server.js"

*/