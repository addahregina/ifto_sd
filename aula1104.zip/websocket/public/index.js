$(()=> {
    const socket = io()
      console.log("conectado ao servidor");

    $("form").submit(()=>{
      socket.emit("message", $("#texto").val())
      return false
    })

    socket.on("message", (texto) => $("#mensagens").append($("<li>").text(texto)))
  
})