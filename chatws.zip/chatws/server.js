const express = require("express")
const app = express()

app.use(express.static("public"))

const http = require("http").Server(app)
const PORT = 8000


const serverSocket = require("socket.io")(http)
//simpflificação da forma utilizada linha 3
//usa mesma porta do servidor http


                  //função de callback
http.listen(PORT, () => console.log(`Servidor iniciado em ${PORT}`))

app.get("/", (_, res) => res.sendFile(`${__dirname}/index.html`))

serverSocket.on("connect", socket => {
    console.log(`Cliente ${socket.id} conectou`)
//    socket.on("chat msg", msg => console.log(`Msg recebida de ${socket.id}: ${msg}`))
      socket.on("chat msg", 
        msg => serverSocket.emit("chat msg", `${socket.username} diz ${msg}`))
        socket.on("login", username => {
        socket.username = username
        serverSocket.emit("chat msg", `Cliente ${username} conectou`)
      })
})


